const express = require("express")
const app = express()
const core = require('cors')
const router = require('./routes/productRoute.js')

// Static middleware

app.use('/uploads', express.static(__dirname + '/uploads'));

app.use(express.json())
app.use(express.urlencoded({extended:true}))

//middleware for front end use

var coreOption = {
    origin:'https:localhost:4200'
}

app.use(core(coreOption))

app.use('/api',router)

app.get('/',(req,res)=>{
    res.status(200).send({message:"Welcome to my app"})
})

app.listen(8000,()=>{
    console.log("Your app running on port 8000");
})
