const db = require('../models')
const Products = db.products

// Create a Product


const createProduct = async (req,res)=>{
    try {
    const paths = 'http://localhost:8000/'
    const createproduct = {
        name:req.body.name,
        description:req.body.description,
        published:req.body.published,
        image:paths+req.file.path,
    }
    const addProduct = await Products.create(createproduct)
    res.status(200).send(addProduct)
    } catch (error) {
        res.status(400).send(error)

    }

}


// Get All Products



const getAllproducts = async (req,res)=>{
    const getAll = await Products.findAll({})
    res.status(200).send(getAll)
}

// Get a Single Product

const getOneProduct = async(req,res)=>{
    const id = req.params.id
    const getOneProduct = await Products.findOne({where:{id:id}})
    res.status(200).send(getOneProduct)
}



// Delete One Product


const deleteProduct = async (req,res)=>{
    const id = req.params.id
    await Products.destroy({where:{id:id}})
    res.status(200).send({message:"Product is Removed Successfully...."})
}

// Delete All Products


const deleteAllProducts = async(req,res)=>{
    await Products.destroy({where:{},truncate:false})
    res.status(200).send({message:"All Products are Deleted...."})
}

// Find Published Product

const publishedProduct = async(req,res)=>{
    try {
        const published = await Products.findAll({where:{published:true}})
        res.status(200).send(published)
    } catch (error) {
        res.status(400).send(error)
    }
}


// Update a Product

const updateProduct = async(req,res)=>{
    try {
        const paths = 'http://localhost:8080/'
        const id = req.params.id

        const updateProducts = {
            name:req.body.name,
            description:req.body.description,
            published:req.body.published,
            image:paths+req.file.path
        }
        await Products.update(updateProducts,{where:{id:id}})
        res.status(200).send("Updated Product Successfully....")
    } catch (error) {
        res.status(500).send({message:"Product Already Exists"})
    }
}


// Find by name

const findByname = async(req,res)=>{
    const name = req.query.name
    const findByName = await Products.findAll({where:{name:name}})
    res.status(200).send(findByName)
}



module.exports = {
    createProduct,
    getAllproducts,
    deleteProduct,
    deleteAllProducts,
    getOneProduct,
    publishedProduct,
    updateProduct,
    findByname
}