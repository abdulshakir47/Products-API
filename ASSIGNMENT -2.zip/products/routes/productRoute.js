const productController = require('../controllers/productController.js')
const router = require('express').Router()
const multer = require('multer')
const express = require('express')
const app = express()

app.use('/uploads', express.static(__dirname + '/uploads'));

const fileStorageEngine = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, './uploads')
    },
    filename: (req, file, cb) => {
      cb(null, file.originalname)
    }
  })
  const upload = multer({ storage: fileStorageEngine });




// Add a product  


router.post('/products',upload.single("image"),productController.createProduct)

router.get('/product/published',productController.publishedProduct)


// Get All Products

router.get('/products',productController.getAllproducts)

// Get One Product

router.get('/product/:id',productController.getOneProduct)

//Delete a Product

router.delete('/product/:id',productController.deleteProduct)

// Delete All Products

router.delete('/products',productController.deleteAllProducts)

// find Published Product


// Update a Product

router.put("/products/:id",upload.single("image"),productController.updateProduct)

// get a query

router.get('/product',productController.findByname)



module.exports = router