module.exports = (sequelize,DataTypes)=>{
    const Products = sequelize.define('product',
    {
        name:{
            type:DataTypes.STRING,
            allowNull:false,

        },
        description:{
            type:DataTypes.STRING,
            allowNull:false,
            

        },
        published:{
            type:DataTypes.BOOLEAN,
            allowNull:false,

        },
        image:{
            type:DataTypes.STRING,
            allowNull:false,
        },
    },
    {
        timestamps: true,

});
    
    return Products
}

